//
//  ViewController.swift
//  ProyectoPrimerParcial
//
//  Created by Alumno on 9/14/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    var playerFondo = AVAudioPlayer()
    var playerAnimal = AVAudioPlayer()
    
    let ulrFondo = Bundle.main.url(forResource: "sonidoFondo", withExtension: "wav")
    let ulrGato = Bundle.main.url(forResource: "cat", withExtension: "wav")
    let ulrPerro = Bundle.main.url(forResource: "dog", withExtension: "wav")
    let urlLoro = Bundle.main.url(forResource: "parrot", withExtension: "wav")
    
    let secuenciaGatoCorriendo = [
        UIImage(named: "gato-c-1")!,
        UIImage(named: "gato-c-2")!,
        UIImage(named: "gato-c-3")!,
        UIImage(named: "gato-c-4")!,
        UIImage(named: "gato-c-5")!,
        UIImage(named: "gato-c-6")!
    ]
    
    let secuenciaGatoSentado = [
        UIImage(named: "gato-s-1")!,
        UIImage(named: "gato-s-2")!,
        UIImage(named: "gato-s-3")!,
        UIImage(named: "gato-s-4")!,
        UIImage(named: "gato-s-5")!,
        UIImage(named: "gato-s-6")!
    ]
    
    let secuenciaPerroCorriendo = [
        UIImage(named: "perro-c-1")!,
        UIImage(named: "perro-c-2")!,
        UIImage(named: "perro-c-3")!,
        UIImage(named: "perro-c-4")!,
        UIImage(named: "perro-c-5")!,
        UIImage(named: "perro-c-6")!
    ]
    
    let secuenciaPerroSentado = [
        UIImage(named: "perro-s-1")!,
        UIImage(named: "perro-s-2")!,
        UIImage(named: "perro-s-3")!,
        UIImage(named: "perro-s-4")!,
        UIImage(named: "perro-s-5")!,
        UIImage(named: "perro-s-6")!
    ]
    
    let secuenciaLoroVolando = [
        UIImage(named: "loro-v-1")!,
        UIImage(named: "loro-v-2")!,
        UIImage(named: "loro-v-3")!,
        UIImage(named: "loro-v-4")!,
        UIImage(named: "loro-v-5")!,
        UIImage(named: "loro-v-6")!
    ]
    
    let secuenciaLoroSentado = [
        UIImage(named: "loro-s-1")!,
        UIImage(named: "loro-s-2")!,
        UIImage(named: "loro-s-3")!,
        UIImage(named: "loro-s-4")!,
        UIImage(named: "loro-s-5")!,
        UIImage(named: "loro-s-6")!
    ]

    @IBOutlet weak var lblNombreAnimal: UILabel!
    @IBOutlet weak var imgAnimacionAnimal: UIImageView!
    @IBOutlet weak var lblSonido: UILabel!
    
    @IBOutlet weak var imgGato: UIImageView!
    @IBOutlet weak var imgPerro: UIImageView!
    @IBOutlet weak var imgLoro: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        do{
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            playerFondo = try AVAudioPlayer(contentsOf: ulrFondo!, fileTypeHint: AVFileType.wav.rawValue)
            playerFondo.numberOfLoops = -1
            playerFondo.volume = 0.2
            playerFondo.play()
        } catch let error {
            print(error.localizedDescription)
        }
        
        imgGato.animationImages = secuenciaGatoCorriendo
        imgGato.animationDuration = 0.8
        imgGato.startAnimating()
        imgPerro.animationImages = secuenciaPerroCorriendo
        imgPerro.animationDuration = 0.8
        imgPerro.startAnimating()
        imgLoro.animationImages = secuenciaLoroVolando
        imgLoro.animationDuration = 0.8
        imgLoro.startAnimating()
    }

    @IBAction func doTapGato(_ sender: Any) {
        
        do{
            playerAnimal = try AVAudioPlayer(contentsOf: ulrGato!, fileTypeHint: AVFileType.wav.rawValue)
            playerAnimal.play()
        } catch let error {
            print(error.localizedDescription)
        }
        
        lblNombreAnimal.text = "Cat"
        lblSonido.text = "Meow meow"
        imgAnimacionAnimal.animationImages = secuenciaGatoSentado
        imgAnimacionAnimal.animationDuration = 1.9
        imgAnimacionAnimal.startAnimating()
    }
    
    @IBAction func doTapPerro(_ sender: Any) {
        
        do{
            playerAnimal = try AVAudioPlayer(contentsOf: ulrPerro!, fileTypeHint: AVFileType.wav.rawValue)
            playerAnimal.play()
        } catch let error {
            print(error.localizedDescription)
        }
        
        lblNombreAnimal.text = "Dog"
        lblSonido.text = "Woof woof"
        imgAnimacionAnimal.animationImages = secuenciaPerroSentado
        imgAnimacionAnimal.animationDuration = 1.0
        imgAnimacionAnimal.startAnimating()
    }
    
    @IBAction func doTapLoro(_ sender: Any) {
        
        do{
            playerAnimal = try AVAudioPlayer(contentsOf: urlLoro!, fileTypeHint: AVFileType.wav.rawValue)
            playerAnimal.play()
        } catch let error {
            print(error.localizedDescription)
        }
        
        lblNombreAnimal.text = "Parrot"
        lblSonido.text = "Squawk"
        imgAnimacionAnimal.animationImages = secuenciaLoroSentado
        imgAnimacionAnimal.animationDuration = 1.0
        imgAnimacionAnimal.startAnimating()
    }
    
    
    
}

